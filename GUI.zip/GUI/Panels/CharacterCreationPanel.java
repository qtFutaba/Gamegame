package GUI.Panels;

import GUI.Controllers.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.Border;

public class CharacterCreationPanel extends JPanel
{
    // Constructor for the main menu.
    public CharacterCreationPanel(CharacterCreationControl ccc)
    {
        // Create the title.
        JLabel label = new JLabel("CREATE YOUR CHARACTER, ADVENTURER.", JLabel.CENTER);
        label.setFont(new Font("Viner Hand ITC", Font.BOLD, 26));
        label.setForeground(Color.WHITE);

        //----------------------------------------------------------------------------------------------------------------
        // Create the character choices.
        //----------------------------------------------------------------------------------------------------------------
        //Warrior. High attack. Medium defense. Low magic.
        JButton warriorButton = new JButton("Warrior");
        warriorButton.addActionListener(ccc);

        Border lineBorder = BorderFactory.createLineBorder(Color.BLACK, 1);
        Border paddingBorder = BorderFactory.createEmptyBorder(10, 10, 10, 10); // 10 pixels padding
        warriorButton.setBorder(BorderFactory.createCompoundBorder(lineBorder, paddingBorder));
        warriorButton.setBackground(Color.BLACK);
        warriorButton.setForeground(Color.WHITE);
        warriorButton.setFont(new Font("Viner Hand ITC", Font.BOLD, 16));


        JPanel warriorButtonBuffer = new JPanel();
        warriorButtonBuffer.add(warriorButton);

        //Mage. Low attack. Medium defense. High magic.
        JButton mageButton = new JButton("Mage");
        mageButton.addActionListener(ccc);
        mageButton.setBorder(BorderFactory.createCompoundBorder(lineBorder, paddingBorder));
        mageButton.setBackground(Color.BLACK);
        mageButton.setForeground(Color.WHITE);
        mageButton.setFont(new Font("Viner Hand ITC", Font.BOLD, 16));


        JPanel mageButtonBuffer = new JPanel();
        mageButtonBuffer.add(mageButton);

        //Noble. High attack. Low defense. High magic.
        JButton nobleButton = new JButton("Noble");
        nobleButton.addActionListener(ccc);
        nobleButton.setBorder(BorderFactory.createCompoundBorder(lineBorder, paddingBorder));
        nobleButton.setBackground(Color.BLACK);
        nobleButton.setForeground(Color.WHITE);
        nobleButton.setFont(new Font("Viner Hand ITC", Font.BOLD, 16));

        JPanel nobleButtonBuffer = new JPanel();
        nobleButtonBuffer.add(nobleButton);

        //----------------------------------------------------------------------------------------------------------------
        //Add choices to the choices panel.
        //----------------------------------------------------------------------------------------------------------------
        JPanel choices = new JPanel(new GridLayout(1, 3, 5, 5));
        choices.add(warriorButtonBuffer);
        choices.add(mageButtonBuffer);
        choices.add(nobleButtonBuffer);


        //----------------------------------------------------------------------------------------------------------------
        // Arrange all components in a grid.
        //----------------------------------------------------------------------------------------------------------------
        JPanel mainGrid = new JPanel(new GridLayout(2, 1, 5, 5));
        mainGrid.add(label);
        mainGrid.add(choices);
        
        // Color.
        mainGrid.setBackground(Color.BLACK);
        choices.setBackground(Color.BLACK);
        warriorButtonBuffer.setBackground(Color.BLACK);
        mageButtonBuffer.setBackground(Color.BLACK);
        nobleButtonBuffer.setBackground(Color.BLACK);

        this.add(mainGrid);
    }
}
