package Game;

import Game.Entities.*;

public class main {
    public static void main(String[] args) {
        // Testing
        Goblin goblin = new Goblin();
        Wizard wizard = new Wizard();
        Orc orc = new Orc();
        Knight knight = new Knight();
        Dragon dragon = new Dragon();
        SecretBoss baarsch = new SecretBoss();

        System.out.println(goblin + "\n");
        System.out.println(wizard + "\n");
        System.out.println(orc + "\n");
        System.out.println(knight + "\n");
        System.out.println(dragon + "\n");
        System.out.println(baarsch + "\n");
    }
}
